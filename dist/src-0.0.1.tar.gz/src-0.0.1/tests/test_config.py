def test_generic():
    a, b = 2,2
    assert a == b